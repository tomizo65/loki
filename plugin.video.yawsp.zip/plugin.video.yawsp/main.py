# -*- coding: utf-8 -*-
# Module: default
# Author: cache
# Created on: 10.5.2020
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import sys
import yawsp

if __name__ == '__main__':
    yawsp.router(sys.argv[2][1:])
